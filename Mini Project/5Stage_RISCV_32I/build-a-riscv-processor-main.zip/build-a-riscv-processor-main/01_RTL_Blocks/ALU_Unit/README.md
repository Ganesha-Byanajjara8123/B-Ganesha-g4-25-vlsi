# Arithmetic Logic Unit (ALU)

## Overview

The Arithmetic Logic Unit (ALU) is the computational core of the processor. It performs arithmetic, logical, shift, and comparison operations required during instruction execution.

This module is implemented in **Verilog HDL** as part of my **5-Stage Pipelined RISC-V Processor** project.

---

## Features

* 32-bit ALU
* Combinational RTL Design (`always @(*)`)
* 10 ALU Operations
* Dedicated Testbench
* GTKWave Simulation

---

## Supported Operations

| ALU Control | Operation                     |
| ----------- | ----------------------------- |
| 0000        | ADD                           |
| 0001        | SUB                           |
| 0010        | AND                           |
| 0011        | OR                            |
| 0100        | XOR                           |
| 0101        | Shift Left Logical (SLL)      |
| 0110        | Shift Right Logical (SRL)     |
| 0111        | Shift Right Arithmetic (SRA)  |
| 1000        | Set Less Than (SLT)           |
| 1001        | Set Less Than Unsigned (SLTU) |

---

## Design Approach

The ALU was designed as a purely combinational block using a `case` statement driven by a 4-bit control signal.

Inputs:

* `src1_in`
* `src2_in`
* `ALU_Control_in`

Output:

* `ALU_Result_out`

The design supports arithmetic, logic, shift, and comparison instructions commonly used in the RISC-V Integer ISA.

---
Block Diagram of ALU:

<img width="1190" height="552" alt="Screenshot 2026-05-24 214858" src="https://github.com/user-attachments/assets/1f554714-8008-448f-895d-3554806387b3" />

---


## Verification

A dedicated Verilog testbench was created to verify every ALU operation.

### Test Configuration

```
src1 = 3
src2 = 5
```
**GTKwaveform:**


<img width="1886" height="634" alt="ALU" src="https://github.com/user-attachments/assets/dc582392-5a67-4121-8323-dab260bbe616" />

---
All supported ALU control codes were applied sequentially.

Simulation was performed using:

* Verilator
* GTKWave

---

## Simulation Result

✔ ADD

✔ SUB

✔ AND

✔ OR

✔ XOR

✔ SLL

✔ SRL

✔ SRA

✔ SLT

✔ SLTU

All operations produced the expected outputs during RTL simulation.

---

---

## Learning Outcome

This module strengthened my understanding of:

* RTL Combinational Design
* ALU Control Logic
* Signed vs Unsigned Comparison
* Logical vs Arithmetic Shifting
* RTL Simulation
* Waveform Analysis

---


## Next Module

➡️ Register File

---

**Building Digital Hardware, One RTL Module at a Time.**
